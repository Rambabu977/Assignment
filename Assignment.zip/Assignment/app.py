from flask import Flask, render_template, request
import os
import time

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/submit", methods=["POST"])
def submit_form():
    name = request.form["name"]
    email = request.form["email"]
    mobile = request.form['mobile']
    address = request.form['address']
     
    with open("submissions.txt", "a") as f:
        f.write(f" Name: {name}, Email: {email}, Mobile: {mobile}, Address: {address}\n")
    return f"Form submitted successfully! Name: {name}, Email: {email}, Mobile No: {mobile}, Address: {address}"

@app.route("/submissions")
def view_submissions():
    submissions = []
    with open("submissions.txt", "r") as f:
        for line in f.readlines():
            submissions.append(line.strip())
    return render_template("submissions.html", submissions=submissions)

@app.route("/delete", methods=["POST"])
def delete_submission():
    submission_to_delete = request.form["submission"]
    submissions = []

    
    with open("submissions.txt", "r") as f:
        submissions = f.readlines()

    
    with open("submissions.txt", "w") as f:
        for submission in submissions:
            if submission.strip() != submission_to_delete:
                f.write(submission)

    return view_submissions()  

if __name__ == "__main__":
    app.run(debug=True)
